
import java.applet.Applet; 
import java.awt.*; 
// // // ListApplet // 

public class ListApplet extends Applet 
{ 
	
	// Private member variables 
	private List m_list; 
	private StatusBar m_status; 
	
	public void init() 
	{ 
		// Panel creation 
		Panel panel = new Panel(); 
		// Create the list, five rows deep without multiple selections 
		m_list = new List(5, false); 
		panel.add(m_list); 
		// Populate list with data 
		m_list.addItem ("Selection 1"); 
		m_list.addItem ("Selection 2");
		m_list.addItem ("Selection 3"); 
		m_list.addItem ("Selection 4"); 
		m_list.addItem ("Selection 5"); 
		
		// Create status bar 
		m_status = new StatusBar ("Value : " ); 
		// Set colors 
		setBackground( Color.white ); 
		setForeground( Color.black ); 
		panel.setBackground( Color.white ); 
		panel.setForeground( Color.black ); 
		m_status.setBackground( Color.white ); 
		m_status.setForeground( Color.black ); 
		
		// Set applet layout 
		setLayout ( new BorderLayout() ); 
		add(panel, "North"); 
		add(m_status, "South"); 
		layout(); 
		} 
	
	public boolean action (Event evt, Object what) 
	{ 
		if ( evt.target == m_list) 
		{ 
			m_status.setStatus ( "Value : " + m_list.getSelectedItem() ); 
			return true; 
		} 
		else 
		return false; 
	} 
}