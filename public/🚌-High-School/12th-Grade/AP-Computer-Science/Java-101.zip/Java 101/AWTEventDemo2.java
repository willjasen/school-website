/* * * AWTEventDemo2.java 
 ** Demonstration for Java 107 tutorial 
 ** David Reilly, 21 February, 1998 * */ 
 
 import java.awt.*; 
 import java.applet.*; 

 public class AWTEventDemo2 extends Applet 
 { 
 	// Private references to AWT components 
 	private NumberTextField numberField; 
 	private Button clear; 
 	
 	// Init method, called when applet first initialises 
 	public void init() 
 	{ 
 		setBackground( Color.white ); 
 		
 		// Set default layout manager 
 		setLayout(new FlowLayout() ); 
 		
 		// Create an instance of NumberTextField .... 
 		numberField = new NumberTextField (10); 
 		
 		// ... and add it to our applet 
 		add(numberField); 
 		
 		// Create an instance of button .... 
 		clear = new Button ("Clear"); 
 		
 		// ... and add it to our applet 
 		add(clear); 
 	} 
 	
 	public boolean action (Event evt, Object what) 
 	{ 
 		// Was the focus of the event our button 
 		if (evt.target == clear) 
 		{ 
 			// Clear the textfield 
 			numberField.setText(""); 
 			
 			// Event handled 
 			return true; 
 		} 
 		else return false; 
 	} 
 } 