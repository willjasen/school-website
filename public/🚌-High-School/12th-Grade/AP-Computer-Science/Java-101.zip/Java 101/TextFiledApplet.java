import java.applet.Applet; 
import java.awt.*; 

public class TextFieldApplet extends Applet 
{ 
	//Private member variables 
	private TextField m_textfield; 
	private StatusBar m_status; public void init() { // Panel creation Panel panel = new Panel(); // Create the textfield m_textfield = new TextField(15); panel.add(m_textfield); // Create status bar m_status = new StatusBar ("Value : " ); // Set colors setBackground( Color.white ); setForeground( Color.black ); panel.setBackground( Color.white ); panel.setForeground( Color.black ); m_status.setBackground( Color.white ); m_status.setForeground( Color.black ); // Set applet layout setLayout ( new BorderLayout() ); add(panel, "North"); add(m_status, "South"); layout(); } public boolean action (Event evt, Object what) { if ( evt.target == m_textfield ) { m_status.setStatus ( "Value : " + m_textfield.getText() ); return true; } else return false; } } 