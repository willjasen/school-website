import java.awt.Panel; 
import java.awt.Label; 
import java.awt.BorderLayout; 
 
 public class StatusBar extends Panel 
{ 
// Private member variables 
private Label m_status; 

// Constructor 
public StatusBar() 
{ 
	this( new String("Hello Everyone") ); 
} 
public StatusBar( String value ) 
{ 
// Create panel 
	setLayout(new BorderLayout()); 
	// Create status bar 
	m_status = new Label(value); 
	add (m_status, "West");
 } 
 // Accessor method for property status 
 public String getStatus() 
 { 
 	return m_status.getText(); 
 } 
 // Accessor method for property status 
 public void setStatus( String newValue ) 
 { m_status.setText( newValue ); 
 // Re-do layout, 
 //because length may be longer than prev value 
 	layout(); 
 } 
 
 } 