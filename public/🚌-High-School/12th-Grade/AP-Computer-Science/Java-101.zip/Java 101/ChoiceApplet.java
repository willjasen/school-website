import java.applet.Applet; 
import java.awt.*; 
// // // ChoiceApplet 
public class ChoiceApplet extends Applet 
{ 
	// Private member variables 
	private Choice m_choice; 
	private StatusBar m_status; 
	
	public void init() 
	{ 
		// Panel creation 
		Panel panel = new Panel(); 
		// Create the choice 
		m_choice = new Choice(); 
		panel.add(m_choice); 
		
		// Populate choice with data 
		m_choice.addItem ("Make a selection"); 
		m_choice.addItem ("Selection 1"); 
		m_choice.addItem ("Selection 2"); 
		m_choice.addItem ("Selection 3"); 
		
		// Create status bar 
		m_status = new StatusBar ("Value : " ); 
		
		// Set colors 
		setBackground( Color.white ); 
		setForeground( Color.black ); 
		panel.setBackground( Color.white ); 
		panel.setForeground( Color.black ); 
		m_status.setBackground( Color.white ); 
		m_status.setForeground( Color.black ); 
		
		// Set applet layout 
		setLayout ( new BorderLayout() ); 
		add(panel, "North"); 
		add(m_status, "South"); 
		layout(); 
	} 
	public boolean action (Event evt, Object what) 
	{ 
		if ( evt.target == m_choice ) 
		{ 
			m_status.setStatus ( "Value : " + m_choice.getSelectedItem() ); 
			return true; 
		} 
		else 
		return false; 
	} 
}